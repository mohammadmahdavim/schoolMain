{{\App\Setting::all()->first()->name}}
