<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Finanace extends Model
{
    protected $guarded = [];

}
