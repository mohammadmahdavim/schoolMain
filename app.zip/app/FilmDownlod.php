<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FilmDownlod extends Model
{
    protected $guarded = [];
    protected $table = 'film_download';

}
