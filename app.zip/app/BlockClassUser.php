<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlockClassUser extends Model
{
    protected $guarded=[];
}
