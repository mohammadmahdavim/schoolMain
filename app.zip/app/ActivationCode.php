<?php

namespace App;

use App\lib\Kavenegar;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Session;

class ActivationCode extends Model
{
    protected $fillable = ['user_id' , 'code' , 'used' , 'expire'];

    public function scopeCreateCode($query , $user)
    {
        $code = $this->code();
        Kavenegar::sendSMS($user->mobile,$code,'VerifyMobileMarket');
        return $query->create([
            'user_id' => $user->id,
            'code' => $code,
            'expire' => Carbon::now()->addMinutes(15)
        ]);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    private function code()
    {
        do {
            $code = rand(10000,99999);
            $check_code = static::whereCode($code)->get();
        } while( ! $check_code->isEmpty() );

        return $code;
    }
}
