<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OptionImage extends Model
{
    public $guarded=[];
}
