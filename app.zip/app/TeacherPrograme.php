<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeacherPrograme extends Model
{
    protected $guarded=[];
}
