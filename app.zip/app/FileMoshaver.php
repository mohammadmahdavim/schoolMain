<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FileMoshaver extends Model
{
    protected $guarded=[];
}
