<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CTags extends Model
{
    protected $guarded = [

    ];
}
