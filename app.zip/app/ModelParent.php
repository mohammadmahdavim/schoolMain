<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelParent extends Model
{
    protected $table = 'parents';
    protected $guarded = [];
}
