<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CKarnameh extends Model
{
    protected $guarded = [];

}
