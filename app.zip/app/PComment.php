<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PComment extends Model
{
    protected $guarded = [

    ];
}
