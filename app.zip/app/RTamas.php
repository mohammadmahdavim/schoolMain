<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RTamas extends Model
{
    protected $guarded = [

    ];
}
