<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RKarnameh extends Model
{
    protected $fillable = ['name', 'status'];

}
