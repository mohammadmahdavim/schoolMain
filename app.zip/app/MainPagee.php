<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MainPagee extends Model
{
    protected $guarded = [

    ];
}
